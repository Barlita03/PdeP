[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/DvwyzEAb)
## Enunciado

[Filosofía](https://docs.google.com/document/d/12J5r7HiIHGGm1AklUfI_CEIZb37j2oJ6QdJfk4DgfL4)
